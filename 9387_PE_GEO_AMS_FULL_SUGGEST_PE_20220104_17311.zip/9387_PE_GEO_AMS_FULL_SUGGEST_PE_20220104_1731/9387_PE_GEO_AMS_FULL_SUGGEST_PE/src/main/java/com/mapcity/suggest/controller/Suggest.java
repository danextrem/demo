package com.mapcity.suggest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mapcity.suggest.response.SuggestResponse;
import com.mapcity.suggest.service.ISearchIndexFileService;

@RestController
public class Suggest {

	@Autowired
	ISearchIndexFileService iSearchIndexFileService;

	@GetMapping("/suggest")
	public SuggestResponse getAll(
			@RequestParam(name = "field") String field,
			@RequestParam(name = "max-results", required = false, defaultValue = "10") int maxResults,
			@RequestParam(name = "country", required = true) String country) {
		return iSearchIndexFileService.findAll(field, maxResults, country);
	}

}
