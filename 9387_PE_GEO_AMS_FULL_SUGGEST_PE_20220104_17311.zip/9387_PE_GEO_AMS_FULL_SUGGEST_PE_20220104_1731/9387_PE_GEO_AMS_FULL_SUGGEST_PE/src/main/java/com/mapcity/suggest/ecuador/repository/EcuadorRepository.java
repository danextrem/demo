package com.mapcity.suggest.ecuador.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.mapcity.suggest.ecuador.model.EcuadorResponse;

@Repository
public class EcuadorRepository {

	@Autowired
	@Qualifier("ecuadorEntityManagerFacatory")
	private EntityManager entityManager;

	public List<EcuadorResponse> findCartoAddress() {
		return entityManager.createQuery("SELECT p FROM EcuadorResponse p", 
				EcuadorResponse.class)
				.setMaxResults(200)
				.getResultList();
	}
}
