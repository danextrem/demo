package com.mapcity.suggest.response;

public class GeoLocation {

	private String lon;
	private String lat;

	public GeoLocation() {
	}

	public String getLon() {
		return lon;
	}

	public void setLon(String lon) {
		this.lon = lon;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	@Override
	public String toString() {
		return "GeoLocation [lon=" + lon + ", lat=" + lat + "]";
	}

}
