package com.mapcity.suggest.service;

import com.mapcity.suggest.response.SuggestResponse;

public interface ISearchIndexFileService {
	SuggestResponse findAll(String name, int maxfield, String country);

}
