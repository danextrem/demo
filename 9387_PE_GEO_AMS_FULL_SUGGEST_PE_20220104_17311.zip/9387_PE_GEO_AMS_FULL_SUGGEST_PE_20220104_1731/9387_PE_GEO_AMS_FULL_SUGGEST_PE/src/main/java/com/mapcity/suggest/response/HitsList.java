package com.mapcity.suggest.response;

public class HitsList {

	private SourceContent _source;

	public SourceContent get_source() {
		return _source;
	}

	public void set_source(SourceContent _source) {
		this._source = _source;
	}

	@Override
	public String toString() {
		return "HitsList [_source=" + _source + "]";
	} 
	
	
	
	
	
}
