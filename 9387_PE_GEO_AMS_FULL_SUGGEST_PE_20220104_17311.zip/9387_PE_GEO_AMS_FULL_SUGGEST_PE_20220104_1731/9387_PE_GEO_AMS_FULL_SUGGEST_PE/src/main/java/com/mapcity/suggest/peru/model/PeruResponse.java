package com.mapcity.suggest.peru.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "carto_address", schema = "ams_tablas")
public class PeruResponse {

	@Id
	private Integer id_address;
	private String ubigeo;
	private String distrito;
	private String provincia;
	private String departamento;
	private String direccion;
	private String geo_nivel;
	private String lon_x;
	private String lat_y;

	public PeruResponse() {
	}

	public Integer getId_address() {
		return id_address;
	}

	public void setId_address(Integer id_address) {
		this.id_address = id_address;
	}

	public String getUbigeo() {
		return ubigeo;
	}

	public void setUbigeo(String ubigeo) {
		this.ubigeo = ubigeo;
	}

	public String getDistrito() {
		return distrito;
	}

	public void setDistrito(String distrito) {
		this.distrito = distrito;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getGeo_nivel() {
		return geo_nivel;
	}

	public void setGeo_nivel(String geo_nivel) {
		this.geo_nivel = geo_nivel;
	}

	public String getLon_x() {
		return lon_x;
	}

	public void setLon_x(String lon_x) {
		this.lon_x = lon_x;
	}

	public String getLat_y() {
		return lat_y;
	}

	public void setLat_y(String lat_y) {
		this.lat_y = lat_y;
	}

	@Override
	public String toString() {
		return "CartoAddressResponse [id_address=" + id_address + ", ubigeo=" + ubigeo + ", distrito=" + distrito
				+ ", provincia=" + provincia + ", departamento=" + departamento + ", direccion=" + direccion
				+ ", geo_nivel=" + geo_nivel + ", lon_x=" + lon_x + ", lat_y=" + lat_y + "]";
	}

}
