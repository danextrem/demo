package com.mapcity.suggest.peru.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.mapcity.suggest.peru.model.PeruResponse;

@Repository
public class PeruRepository {
	@Autowired
	@Qualifier("peruEntityManagerFacatory")
	private EntityManager entityManager;
	
	public List<PeruResponse> findCartoAddress() {		
        return entityManager.createQuery("SELECT p FROM PeruResponse p",
        		PeruResponse.class)        		
        		.setMaxResults(10)        		
        		.getResultList();
    }
}
