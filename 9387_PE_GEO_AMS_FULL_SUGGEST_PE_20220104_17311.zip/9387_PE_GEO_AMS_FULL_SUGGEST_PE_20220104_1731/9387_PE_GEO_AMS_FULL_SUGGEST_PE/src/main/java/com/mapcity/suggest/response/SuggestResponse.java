package com.mapcity.suggest.response;

public class SuggestResponse {
	
	private Hits hits;

	public Hits getHits() {
		return hits;
	}

	public void setHits(Hits hits) {
		this.hits = hits;
	}

	@Override
	public String toString() {
		return "SuggestResponse [hits=" + hits + "]";
	}
	
	

}
