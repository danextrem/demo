package com.mapcity.suggest.service;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.demo.knn.KnnVectorDict;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mapcity.suggest.ecuador.model.EcuadorResponse;
import com.mapcity.suggest.ecuador.repository.EcuadorRepository;
import com.mapcity.suggest.peru.model.PeruResponse;
import com.mapcity.suggest.peru.repository.PeruRepository;
import com.mapcity.suggest.utils.IndexEcuadorFiles;
import com.mapcity.suggest.utils.IndexPeruFiles;

@Service
public class CreateIndexFileServiceImp {
	@Value("${peru.dir.index.path}")
	String indexPeruPath;

	@Value("${ecuador.dir.index.path}")
	String indexEcuadorPath;

	@Autowired
	EcuadorRepository ecuadorRepository;
	
	@Autowired
	PeruRepository peruRepository;	
	
	private static final Logger logger = LoggerFactory.getLogger(CreateIndexFileServiceImp.class);

	public void starIndex() throws Exception {
		logger.info("Ruta donde se guardar el Index Perú: " + indexPeruPath);
		List<PeruResponse> findPeruCartoAddress = peruRepository.findCartoAddress();
		processBatchPeru(indexPeruPath, findPeruCartoAddress);
		
		
		logger.info("Ruta donde se guardar el Index Ecuador: " + indexEcuadorPath);
		List<EcuadorResponse> findEcuadorCartoAddress = ecuadorRepository.findCartoAddress();
		processBatchEcuador(indexEcuadorPath, findEcuadorCartoAddress);
	}

	private void processBatchEcuador(String indexEcuadorPath, List<EcuadorResponse> findCartoAddress)  throws Exception {
		logger.info("Entro a Procesar Ecuador");
		
		Date start = new Date();
		try {
			logger.info("Indexing to directory Peru'" + indexEcuadorPath + "'...");			
			Directory dir = FSDirectory.open(Paths.get(indexEcuadorPath));
			Analyzer analyzer = new StandardAnalyzer();
			IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
			iwc.setOpenMode(OpenMode.CREATE);

			KnnVectorDict vectorDictInstance = null;
			try (IndexWriter writer = new IndexWriter(dir, iwc);
					IndexEcuadorFiles indexFiles = new IndexEcuadorFiles(vectorDictInstance)) {
				indexFiles.indexDocs(writer, findCartoAddress);
			} finally {
				IOUtils.close(vectorDictInstance);
			}
			Date end = new Date();
			try (IndexReader reader = DirectoryReader.open(dir)) {
				System.out.println("Indexed " + reader.numDocs() + " documents in " + (end.getTime() - start.getTime())
						+ " milliseconds");
			}
		} catch (IOException e) {
			System.out.println(" caught a " + e.getClass() + "\n with message: " + e.getMessage());
		}
	}

	

	private void processBatchPeru(String indexPath, List<PeruResponse> findCartoAddress) throws Exception {
		Date start = new Date();
		try {
			logger.info("Indexing to directory Peru'" + indexPath + "'...");			
			Directory dir = FSDirectory.open(Paths.get(indexPath));
			Analyzer analyzer = new StandardAnalyzer();
			IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
			iwc.setOpenMode(OpenMode.CREATE);

			KnnVectorDict vectorDictInstance = null;
			try (IndexWriter writer = new IndexWriter(dir, iwc);
					IndexPeruFiles indexFiles = new IndexPeruFiles(vectorDictInstance)) {
				indexFiles.indexDocs(writer, findCartoAddress);
			} finally {
				IOUtils.close(vectorDictInstance);
			}
			Date end = new Date();
			try (IndexReader reader = DirectoryReader.open(dir)) {
				System.out.println("Indexed " + reader.numDocs() + " documents in " + (end.getTime() - start.getTime())
						+ " milliseconds");
			}
		} catch (IOException e) {
			System.out.println(" caught a " + e.getClass() + "\n with message: " + e.getMessage());
		}
	}

}
