# 9387_PE_GEO_AMS_FULL_SUGGEST_PE

1.- Servicio de prueba configurado en puerto local : 8080 con dos parametros

http://localhost:8080/suggest?field=AVENIDA&max-results=2

2.- Nunca subir la carpeta INDEX que se genera al construir el proyecto
