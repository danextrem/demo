package com.mapcity.suggest.response;

import java.util.List;

public class Hits {	
	
	private List<HitsList> hits ;

	public List<HitsList> getHits() {
		return hits;
	}

	public void setHits(List<HitsList> hits) {
		this.hits = hits;
	}
	
	

}
