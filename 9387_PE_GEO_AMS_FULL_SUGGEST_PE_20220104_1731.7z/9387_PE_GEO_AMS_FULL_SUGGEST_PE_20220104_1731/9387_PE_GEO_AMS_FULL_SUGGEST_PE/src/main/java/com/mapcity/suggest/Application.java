package com.mapcity.suggest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import com.mapcity.suggest.service.CreateIndexFileServiceImp;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Component
	public class CommandLineAppStartupRunner implements CommandLineRunner {
	    @Autowired
	    private CreateIndexFileServiceImp createIndexFileServiceImp;

	    @Override
	    public void run(String...args) throws Exception {
	    	createIndexFileServiceImp.starIndex();
	    }
	}
}