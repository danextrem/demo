package com.mapcity.suggest;



import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
		entityManagerFactoryRef = "ecuadorEntityManagerFacatory", 
				transactionManagerRef = "ecuadorTransactionManager", 
				basePackages = { "com.mapcity.suggest.ecuador.repository" })
public class DbaEcuadorConfig {	
	@Autowired
	private Environment env;
	
	@Bean(name = "ecuadorDataSource")
	public DataSource ecuadorDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setUrl(env.getProperty("ecuador.datasource.url"));
		dataSource.setUsername(env.getProperty("ecuador.datasource.username"));
		dataSource.setPassword(env.getProperty("ecuador.datasource.password"));
		dataSource.setDriverClassName(env.getProperty("ecuador.datasource.driver-class-name"));		
		return dataSource;
	}
	
	@Bean(name = "ecuadorEntityManagerFacatory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(ecuadorDataSource());
		em.setPackagesToScan("com.mapcity.suggest.ecuador.model");
		
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		
		Map<String, Object> properties = new HashMap<>();		
		properties.put("hibernate.show-sql", env.getProperty("ecuador.jpa.show-sql"));
		properties.put("hibernate.dialect", env.getProperty("ecuador.jpa.database-platform"));		
		em.setJpaPropertyMap(properties);		
		return em;		
	}
	
	@Bean(name = "ecuadorTransactionManager")
	public PlatformTransactionManager transactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());		
		return transactionManager;
	}	
	

}
