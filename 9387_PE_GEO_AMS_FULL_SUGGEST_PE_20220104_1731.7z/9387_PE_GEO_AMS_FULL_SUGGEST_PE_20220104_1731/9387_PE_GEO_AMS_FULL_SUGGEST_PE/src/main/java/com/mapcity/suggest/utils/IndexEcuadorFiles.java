package com.mapcity.suggest.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.lucene.demo.knn.DemoEmbeddings;
import org.apache.lucene.demo.knn.KnnVectorDict;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.util.IOUtils;

import com.mapcity.suggest.ecuador.model.EcuadorResponse;


public class IndexEcuadorFiles implements AutoCloseable {
	  static final String KNN_DICT = "knn-dict";

	  private final KnnVectorDict vectorDict;

	  public IndexEcuadorFiles(KnnVectorDict vectorDict) throws IOException {
	    if (vectorDict != null) {
	      this.vectorDict = vectorDict;
	      new DemoEmbeddings(vectorDict);
	    } else {
	      this.vectorDict = null;
	    }
	  }

	@Override
	public void close() throws Exception {
		IOUtils.close(vectorDict);		
	}
	

	public void indexDocs(IndexWriter writer, List<EcuadorResponse> personasList) throws IOException {
		if (personasList.size() != -1) {
	    	for (EcuadorResponse cartoAddress: personasList) {
	    		indexDoc(writer, cartoAddress);
			}    	
	    } else {
	      indexDoc(writer, personasList.get(0));
	    }		
	}	

	
	void indexDoc(IndexWriter writer, EcuadorResponse file) throws IOException {
	    try (InputStream stream = new ByteArrayInputStream((file.getDireccion()).getBytes())) {
	      Document doc = new Document();
	      Field idAddress = new StringField("idAddress", String.valueOf(file.getId_address()), Field.Store.YES);
	      Field ubigeo = new StringField("ubigeo", file.getUbigeo() ==null?"":file.getUbigeo(), Field.Store.YES);	      
	      Field distrito = new StringField("distrito", file.getDistrito() == null ? "" : file.getDistrito(), Field.Store.YES);
	      Field provincia = new StringField("provincia", file.getProvincia() == null ? "" : file.getProvincia(), Field.Store.YES);
	      Field departamento = new StringField("departamento", file.getDepartamento() == null ? "" : file.getDepartamento() , Field.Store.YES);	      
	      Field geoNivel = new StringField("geoNivel", file.getGeo_nivel() == null ? "" : file.getGeo_nivel() , Field.Store.YES);
	      Field lonX = new StringField("lonX", file.getLon_x() == null ? "" : file.getLon_x() , Field.Store.YES);
	      Field latY = new StringField("latY", file.getLat_y() == null ? "" : file.getLat_y() , Field.Store.YES);
	      Field direccion = new StringField("direccion", file.getDireccion() == null ? "" : file.getDireccion(), Field.Store.YES);
	      doc.add(idAddress);
	      doc.add(ubigeo);
	      doc.add(distrito);
	      doc.add(provincia);
	      doc.add(departamento);
	      doc.add(direccion);
	      doc.add(geoNivel);
	      doc.add(lonX);
	      doc.add(latY);
	      doc.add(new TextField("contents",new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))));
  

	      if (writer.getConfig().getOpenMode() == OpenMode.CREATE) {
	        System.out.println("adding " + doc);
	        writer.addDocument(doc);
	      } else {

	        System.out.println("updating " + doc);
	        writer.updateDocument(new Term("path", file.toString()), doc);
	      }
	    }
	  }
}