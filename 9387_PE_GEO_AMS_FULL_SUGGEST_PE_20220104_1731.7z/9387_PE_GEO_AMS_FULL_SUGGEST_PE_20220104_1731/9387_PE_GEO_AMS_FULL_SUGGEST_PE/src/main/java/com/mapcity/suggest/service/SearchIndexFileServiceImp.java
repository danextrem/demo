package com.mapcity.suggest.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.demo.knn.DemoEmbeddings;
import org.apache.lucene.demo.knn.KnnVectorDict;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.KnnVectorQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryVisitor;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mapcity.suggest.response.GeoLocation;
import com.mapcity.suggest.response.Hits;
import com.mapcity.suggest.response.HitsList;
import com.mapcity.suggest.response.SourceContent;
import com.mapcity.suggest.response.SuggestResponse;

@Service
public class SearchIndexFileServiceImp implements ISearchIndexFileService {
	private static final Logger logger = LoggerFactory.getLogger(SearchIndexFileServiceImp.class);
	static final String KNN_DICT = "knn-dict";

	@Value("${peru.dir.index.path}")
	String peruIndex;
	
	@Value("${ecuador.dir.index.path}")
	String ecuadorIndex;

	@Override
	public SuggestResponse findAll(String name, int maxfield, String country) {
		
		SuggestResponse response = new SuggestResponse();
		Hits hits = new Hits();
		List<HitsList> lista = new ArrayList<>();

		String field = "contents";
		String queries = null;
		int repeat = 0;
		boolean raw = false;
		int knnVectors = 0;
		String queryString = null;
		int hitsPerPage = maxfield;
		
		String index = country.equals("peru")?peruIndex:ecuadorIndex;
		logger.info("Pais que va a buscar:  " + index);

		try {
			DirectoryReader reader = DirectoryReader.open(FSDirectory.open(Paths.get(index)));
			IndexSearcher searcher = new IndexSearcher(reader);
			Analyzer analyzer = new StandardAnalyzer();
			KnnVectorDict vectorDict = null;
			if (knnVectors > 0) {
				vectorDict = new KnnVectorDict(reader.directory(), KNN_DICT);
			}
			BufferedReader in;
			in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
			QueryParser parser = new QueryParser(field, analyzer);
			name = name.trim();
			Query query = parser.parse(name);
			if (knnVectors > 0) {
				query = addSemanticQuery(query, vectorDict, knnVectors);
			}
			System.out.println("Searching for: " + query.toString(field));

			if (repeat > 0) {
				Date start = new Date();
				for (int i = 0; i < repeat; i++) {
					searcher.search(query, 100);
				}
				Date end = new Date();
				System.out.println("Time: " + (end.getTime() - start.getTime()) + "ms");
			}

			lista = doPagingSearch(in, searcher, query, hitsPerPage, raw, queries == null && queryString == null);
			System.out.println("Imprime: " + lista);

			if (vectorDict != null) {
				vectorDict.close();
			}
			reader.close();

		} catch (Exception e) {
			// TODO: handle exception
		}

		hits.setHits(lista);
		response.setHits(hits);
		return response;
	}

	public static List<HitsList> doPagingSearch(BufferedReader in, IndexSearcher searcher, Query query, int hitsPerPage,
			boolean raw, boolean interactive) throws IOException {

		List<HitsList> hitsListContent = new ArrayList<>();

		TopDocs results = searcher.search(query, 5 * hitsPerPage);
		ScoreDoc[] hits = results.scoreDocs;

		int numTotalHits = Math.toIntExact(results.totalHits.value);
		System.out.println(numTotalHits + " total matching documents");

		int start = 0;
		int end = Math.min(numTotalHits, hitsPerPage);

		for (int i = start; i < end; i++) {
			if (raw) { // output raw format
				System.out.println("doc=" + hits[i].doc + " score=" + hits[i].score);
				start++;
			}

			Document doc = searcher.doc(hits[i].doc);
			if (doc.get("idAddress") != null) {
				System.out.println((i + 1) + "Id: " + doc.get("idAddress") + "Direccion: " + doc.get("direccion"));
				HitsList hitsContens = new HitsList();
				SourceContent sourceContent = new SourceContent();
				sourceContent.setDireccion(doc.get("direccion"));
				sourceContent.setDistrito(doc.get("distrito"));
				sourceContent.setProvincia(doc.get("provincia"));
				sourceContent.setDepartamento(doc.get("departamento"));
				GeoLocation geoLocation = new GeoLocation();
				geoLocation.setLon(doc.get("lonX"));
				geoLocation.setLat(doc.get("latY"));
				sourceContent.setLocation(geoLocation);
				hitsContens.set_source(sourceContent);
				hitsListContent.add(hitsContens);

				String title = doc.get("title");
				if (title != null) {
					System.out.println("   Title: " + doc.get("title"));
				}
			} else {
				System.out.println((i + 1) + ". " + "No path for this document");
			}

		}
		return hitsListContent;
	}

	private static Query addSemanticQuery(Query query, KnnVectorDict vectorDict, int k) throws IOException {
		StringBuilder semanticQueryText = new StringBuilder();
		QueryFieldTermExtractor termExtractor = new QueryFieldTermExtractor("contents");
		query.visit(termExtractor);
		for (String term : termExtractor.terms) {
			semanticQueryText.append(term).append(' ');
		}
		if (semanticQueryText.length() > 0) {
			KnnVectorQuery knnQuery = new KnnVectorQuery("contents-vector",
					new DemoEmbeddings(vectorDict).computeEmbedding(semanticQueryText.toString()), k);
			BooleanQuery.Builder builder = new BooleanQuery.Builder();
			builder.add(query, BooleanClause.Occur.SHOULD);
			builder.add(knnQuery, BooleanClause.Occur.SHOULD);
			return builder.build();
		}
		return query;
	}

	private static class QueryFieldTermExtractor extends QueryVisitor {
		private final String field;
		private final List<String> terms = new ArrayList<>();

		QueryFieldTermExtractor(String field) {
			this.field = field;
		}

		@Override
		public boolean acceptField(String field) {
			return field.equals(this.field);
		}

		@Override
		public void consumeTerms(Query query, Term... terms) {
			for (Term term : terms) {
				this.terms.add(term.text());
			}
		}

		@Override
		public QueryVisitor getSubVisitor(BooleanClause.Occur occur, Query parent) {
			if (occur == BooleanClause.Occur.MUST_NOT) {
				return QueryVisitor.EMPTY_VISITOR;
			}
			return this;
		}
	}

}
