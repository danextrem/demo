package com.mapcity.suggest.service;

import java.util.List;

import com.mapcity.suggest.peru.model.PeruResponse;

public interface ICreateIndexFileService {
	List<PeruResponse> findAll();
}
